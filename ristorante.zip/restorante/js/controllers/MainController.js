app.controller('MainController', [
  '$scope',
  function ($scope) {
    $scope.today = new Date();

    $scope.appetizers = [
      {
        name: 'Caprese',
        description: 'Mozzarella, tomatoes, basil, balsmaic glaze.',
        price: 14.95,
      },
      {
        name: 'Mozzarella Sticks',
        description: 'Served with marinara sauce.',
        price: 12.95,
      },
      {
        name: 'Bruschetta',
        description: 'Grilled garlic bread, fresh tomatoes, basil, olive oil',
        price: 9.95,
      },
      {
        name: 'Garlic Knots',
        description: 'Made fresh, with lots of garlic',
        price: 7.25,
      },
    ];
    $scope.mains = [
      {
        name: 'Spaghetti & Meatballs',
        description: 'The Italian-American classic.',
        price: 19.95,
      },
      {
        name: 'Chicken ala Parmasean',
        description:
          'Breaded and fried to perfection. Served with your choice of pasta',
        price: 16.95,
      },
      {
        name: 'Chicken Milanese',
        description: 'Lightly fried, served with mashed potatoes.',
        price: 14.95,
      },
      {
        name: 'Dinner Antipaste',
        description:
          'Platter of fresh and cured meats, cheeses, and vegetables.',
        price: 17.5,
      },
      {
        name: 'Ravioli fra Diavlo',
        description: 'Cheese raviolli served with a spicy marinara sauce.',
        price: 15.75,
      },
      {
        name: 'Pork Marsala',
        description: 'Pork cutlets served with a mushroom wine sauce.',
        price: 13.95,
      },
    ];
  },
]);
